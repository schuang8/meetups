# Solo Roadmap (Trimmed)

**Phase 0**: App compiles & shows fake feed (this repo).  
**Phase 1**: Real screens with mock data; widget shell.  
**Phase 2**: Firestore schema + Rules (emulator).  
**Phase 3**: Read `place_aggregates` (seeded).  
**Phase 4**: Presence write + auto-expire.  
**Phase 5**: Functions aggregator.  
**Phase 6**: Plans + Interested.  
**Phase 7**: ETAs with caching.  
**Phase 8**: Privacy controls.  
**Phase 9**: Notifications + widget polish.  
**Phase 10**: Perf/battery pass; Private Preview prep.
