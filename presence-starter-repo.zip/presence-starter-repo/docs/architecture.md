# Architecture (Starter)

- **Android app**: Jetpack Compose UI, a simple repository pattern with a mock data source (swap for Firestore later).
- **Firebase (later)**: Firestore for realtime aggregates, Cloud Functions for aggregation and ETAs, FCM for nudges.
- **Privacy**: time-boxed presence, approximate location option, least-privilege reads via Security Rules.

## Collections (planned)
- `users`, `venues`, `plans`, `presence`, `interests`, `place_aggregates`, `devices/{userId}/tokens/{tokenId}`

## Next steps
- Wire Firestore read of `place_aggregates` into `FeedViewModel`.
- Add "Share now" → write to `presence` (expiresAt).
- Functions: recompute counts on presence/interest writes.
